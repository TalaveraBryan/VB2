﻿Imports System.Windows.Forms.VisualStyles.VisualStyleElement

Public Class Form1
    Dim LRN As Integer = 1
    Private Sub Label1_Click(sender As Object, e As EventArgs) Handles Label1.Click

    End Sub

    Private Sub Label6_Click(sender As Object, e As EventArgs)

    End Sub

    Private Sub Label3_Click(sender As Object, e As EventArgs) Handles Label3.Click

    End Sub

    Private Sub TextBox3_TextChanged(sender As Object, e As EventArgs) Handles TextBox3.TextChanged

    End Sub

    Private Sub TextBox11_TextChanged(sender As Object, e As EventArgs) Handles TextBox11.TextChanged

    End Sub

    Private Sub TextBox17_TextChanged(sender As Object, e As EventArgs) Handles TextBox17.TextChanged

    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        TextBox3.Text = TextBox1.Text
        TextBox9.Text = TextBox2.Text
        TextBox17.Text = TextBox8.Text
        TextBox16.Text = TextBox7.Text
        TextBox15.Text = TextBox5.Text
        TextBox13.Text = TextBox6.Text
        TextBox14.Text = TextBox4.Text
        Dim AL As Double = TextBox5.Text
        Dim IR As Double = TextBox6.Text
        Dim YTP As Double = TextBox4.Text


        Dim ti = (AL * (IR / 100) * YTP)
        TextBox11.Text = Format(ti, "₱#,##.00")
        Dim TLP As Double = AL + ti
        TextBox18.Text = Format(TLP, "₱#,##.00")
        Dim TAP As Double = TLP / YTP
        TextBox10.Text = Format(TAP, "₱#,##.00")
        Dim MP As Double = TAP / 12
        TextBox12.Text = Format(MP, "₱#,##.00")



    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Dim clear As String = " "
        TextBox2.Text = clear
        TextBox3.Text = clear
        TextBox4.Text = clear
        TextBox5.Text = clear
        TextBox6.Text = clear
        TextBox7.Text = clear
        TextBox8.Text = clear
        TextBox9.Text = clear
        TextBox10.Text = clear
        TextBox11.Text = clear
        TextBox12.Text = clear
        TextBox13.Text = clear
        TextBox14.Text = clear
        TextBox15.Text = clear
        TextBox16.Text = clear
        TextBox17.Text = clear
        TextBox18.Text = clear
        LRN += 1
        TextBox1.Text = "0000" & LRN


    End Sub
End Class
